using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DeviceApplication2
{
    public partial class Calendar : Form
    {
        public Calendar()
        {
            InitializeComponent();
        }
    }
}