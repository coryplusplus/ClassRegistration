using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace DeviceApplication2
{
    public class File_IO
    {
        private User client;
        private string file_name;

        public File_IO()
        {
            client = null;
            file_name = null;
        }

        /*/public File_IO(User x, string file)
        {
            client = x; WHAT ZE FUCK IS DAT?
            file_name = file;
        }/*/

        public void set_client(User x)
        {
            client = x;
        }

        public void set_file_name(string x)
        {
            file_name = x;
        }

        /*public void create_search_object()
        {
            //this is where the check boxes will be crucial
            //search based on what is filled in/checked 
            //???Possibly use a set to store sorted items???
            //Search elements of what we'll call the MasterClass.xml file (contains all courses and their info)

        }
        public void create_schedule_object()
        {
            //if student doesn't have a page already b/c they have not registered yet...
            //create a new schedule object and build frame of xml document

        }
        public void create_class_object()
        {
            //NO FREAKING IDEA WHAT THE PURPOSE OF THIS IS?  IS THIS WHERE THE QUEUED 
            //CLASSES ARE GOING?  THE APPLICATION SHOULD NOT CREATE NEW CLASSES
        }*/
        public void write_schedule()//ALL CODE IN WRITES IS A SIMPLE FRAMEWORK RIGHT NOW!
            //write to saved schedule file
        {
            XmlTextWriter writer = new XmlTextWriter("L:\\Visual Studio 2005\\Projects\\xmlTest\\xmlTest\\testing.xml", null);
            writer.WriteStartDocument();

            writer.WriteComment("First Comment to test XML Writer");
            writer.WriteStartElement("Student");
            writer.WriteStartElement("r", "Record", "urn:record");

            writer.WriteEndElement();


            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
            Console.WriteLine(writer);
        }

        public bool request_add_course(string crn)
        {
            //sends to server the CRN...server will use CRN to add courses to that person's registration
            //Server returns true or false if one can add this class
            return true;
        }
        public bool request_remove_course(int crn)
        {
            return true;
        }
        public void request_lookup(string subj, string courseNum)
        {//Call searchresponse.xml and return list of classes based on server side logic
            //write a searchrequest.xml file to the server   
            try
            {
                XmlTextWriter writer = new XmlTextWriter("L:\\Visual Studio 2008\\searchResult.xml", null);
                writer.WriteStartDocument();
                writer.WriteStartElement("CourseSearch");

                writer.WriteStartElement("Subject");
                writer.WriteString(subj);
                writer.WriteEndElement();

                writer.WriteStartElement("CourseNum");
                writer.WriteString(courseNum);
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        /*public void request_schedule()
        {
            //Again is this where the XML student online document is loaded?
        }*/
        public Boolean request_login(User clientLog)
        {
            try
            {
                Boolean id = false;
                string test = "";
                if ((clientLog.getID() == "") || (clientLog.getPassword() == "")) return false;

                XmlTextWriter writer = new XmlTextWriter("L:\\Visual Studio 2008\\loginResult.xml", null);
                writer.WriteStartDocument();
                writer.WriteStartElement("StudentLog");

                writer.WriteStartElement("ID");
                writer.WriteString(clientLog.getID().ToString());
                writer.WriteEndElement();

                writer.WriteStartElement("PW");
                writer.WriteString(clientLog.getPassword().ToString());
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
                XmlTextReader read = new XmlTextReader("loginresponse.xml");//Could have implemented in a database
                while (read.Read())
                {
                    switch (read.NodeType)
                    {
                        case XmlNodeType.Text:
                            test = read.Value.ToString();
                            if (test == "TRUE") { id = true; }
                            break;
                    }
                }
                read.Close();
                if (id == true)
                    return true;


                return false;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

        }
    }
}
