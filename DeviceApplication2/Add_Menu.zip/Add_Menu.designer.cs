namespace DeviceApplication2
{
    partial class Add_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.crn_label = new System.Windows.Forms.Label();
            this.crn_input = new System.Windows.Forms.TextBox();
            this.submit_crn = new System.Windows.Forms.Button();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // crn_label
            // 
            this.crn_label.Location = new System.Drawing.Point(42, 74);
            this.crn_label.Name = "crn_label";
            this.crn_label.Size = new System.Drawing.Size(158, 35);
            this.crn_label.Text = "Enter CRN Number:";
            // 
            // crn_input
            // 
            this.crn_input.Location = new System.Drawing.Point(42, 112);
            this.crn_input.MaxLength = 5;
            this.crn_input.Name = "crn_input";
            this.crn_input.Size = new System.Drawing.Size(100, 21);
            this.crn_input.TabIndex = 1;
            this.crn_input.Text = "#####";
            // 
            // submit_crn
            // 
            this.submit_crn.Location = new System.Drawing.Point(42, 191);
            this.submit_crn.Name = "submit_crn";
            this.submit_crn.Size = new System.Drawing.Size(72, 20);
            this.submit_crn.TabIndex = 2;
            this.submit_crn.Text = "Submit";
            this.submit_crn.Click += new System.EventHandler(this.submit_crn_Click);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Quit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // Add_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.submit_crn);
            this.Controls.Add(this.crn_input);
            this.Controls.Add(this.crn_label);
            this.Menu = this.mainMenu1;
            this.Name = "Add_Menu";
            this.Text = "Add Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label crn_label;
        private System.Windows.Forms.TextBox crn_input;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.Button submit_crn;
    }
}