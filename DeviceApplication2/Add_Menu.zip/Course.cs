using System;
using System.Collections.Generic;
using System.Text;

namespace DeviceApplication2
{
   public class Course
    {
       private string Select = null;
       private string CRN = null;
       private string Subj = null;
       private string Crse = null;
       private string Sec = null;
       private string Cmp = null;
       private string Cred = null;
       private string Title = null;
       private string Day = null;
       private string Time = null;
       private string Cap = null;
       private string Act = null;
       private string Rem = null;
       private string WL_Cap = null;
       private string WL_Act = null;
       private string WL_Rem = null;
       private string Instructor = null;
       private string Date = null;
       private string Location = null;
       private string Attr = null;
        /////////////////////////////Access/////////////////////////////////////
       public string getSelect() { return Select; }
       public string getCRN() { return CRN; }
       public string getSubj() { return Subj; }
       public string getCrse() { return Crse; }
       public string getSec() { return Sec; }
       public string getCmp() { return Cmp; }
       public string getCred() { return Cred; }
       public string getTitle() { return Title; }
       public string getDay() { return Day; }
       public string getTime() { return Time; }
       public string getCap() { return Cap; }
       public string getAct() { return Act; }
       public string getRem() { return Rem; }
       public string getWL_Cap() { return WL_Cap; }
       public string getWL_Act() { return WL_Act; }
       public string getWL_Rem() { return WL_Rem; }
       public string getInstructor() { return Instructor; }
       public string getDate() { return Date; }
       public string getLocation() { return Location; }
       public string getAttr() { return Attr; }
        ///////////////////////////////modifiy/////////////////////////////////////////////
       public void setSelect(string x) { Select = x; }
       public void setCRN(string x) { CRN = x; }
       public void setSubj(string x) { Subj = x; }
       public void setCrse(string x) { Crse = x; }
       public void setSec(string x) { Sec = x; }
       public void setCmp(string x) { Cmp = x; }
       public void setCred(string x) { Cred = x; }
       public void setTitle(string x) { Title = x; }
       public void setDay(string x) { Day = x; }
       public void setTime(string x) { Time = x; }
       public void setCap(string x) { Cap = x; }
       public void setAct(string x) { Act = x; }
       public void setRem(string x) { Rem = x; }
       public void setWL_Cap(string x) { WL_Cap = x; }
       public void setWL_Act(string x) { WL_Act = x; }
       public void setWL_Rem(string x) { WL_Rem = x; }
       public void setInstructor(string x) { Instructor = x; }
       public void setDate(string x) { Date = x; }
       public void setLocation(string x) { Location = x; }
       public void setAttr(string x) { Attr = x; }

       public string shortprint_course()
       {
           string print = getCRN() + "  " + getSubj() + "   " + getCrse() + "   " + getSec();
           return print;


       }
       public string longprint_course()//Will append to it later when we decide what kind of
                                      //way the display will be laid out or whatever
       {
           return "blah";
       }
      
       }
      
    }

