using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DeviceApplication2
{
    public partial class Add_Menu : Form
    {
        public File_IO sending = new File_IO();
        public File_IO receiving = new File_IO();
        private Schedule course_schedule = new Schedule();
        public Add_Menu(File_IO send, File_IO receive, Schedule schedule)
        {
            sending = send;
            receiving = receive;
            course_schedule = schedule;
            InitializeComponent();
        }

        private void menuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void submit_crn_Click(object sender, EventArgs e)
        {
            string response = "";   
            sending.request_add_course(crn_input.Text);
            //response = receiving.read_file();
            if(response == "Success")
            {
                sending.request_add_course(crn_input.Text);
                                
            }
            else
            {
            MessageBox.Show("Unable to add course");
            }
        }
    }
}